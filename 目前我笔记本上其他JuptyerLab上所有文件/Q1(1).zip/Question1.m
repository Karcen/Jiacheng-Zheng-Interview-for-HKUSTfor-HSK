clear all
Year=[2019
    2020
    2021
    2022
    2023];

CatTrain=[4412
4862
5806
6536
6980
];

DogTrain=[5175
5119
5429
5222
5503
];

YearPredict=[2019
    2020
    2021
    2022
    2023
    2024
    2025
    2026];

CatPredict=trainedModel.predictFcn(YearPredict); 
DogPredict=trainedModel1.predictFcn(YearPredict); 